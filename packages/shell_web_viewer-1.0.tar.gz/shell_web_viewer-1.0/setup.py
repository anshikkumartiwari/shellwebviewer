from setuptools import setup, find_packages

setup(
    name="shell-web-viewer",
    version="1.0",
    description="A terminal-based web viewer that opens a GUI window for browsing. Search anything using webv command",
    author="anshikkumartiwari",
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        "PyQt6",
    ],
    entry_points={
        'console_scripts': [
            'webv=shellweb.shell:main',
        ],
    },
    include_package_data=True,
    data_files=[('assets', ['assets/icon.png'])],
)
